"""
Audit dataset NEU-DET untuk tugas persiapan dataset citra.
Memeriksa integritas gambar, duplikasi SHA-256, pasangan image/XML,
distribusi kelas, dan validitas bounding box Pascal VOC.
"""
from pathlib import Path
from collections import defaultdict
import argparse, hashlib, json, csv, xml.etree.ElementTree as ET
from PIL import Image

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}

def images_in(split_dir):
    root = split_dir / "images"
    return sorted(p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in IMG_EXTS) if root.exists() else []

def xmls_in(split_dir):
    root = split_dir / "annotations"
    return sorted(root.rglob("*.xml")) if root.exists() else []

def write_csv(path, rows):
    rows = list(rows)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

def main(dataset_dir, output_dir):
    dataset = Path(dataset_dir).resolve()
    out = Path(output_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    image_rows, hashes = [], defaultdict(list)
    for split in ("train", "validation", "test"):
        for p in images_in(dataset / split):
            rel = str(p.relative_to(dataset))
            try:
                digest = hashlib.sha256(p.read_bytes()).hexdigest()
                with Image.open(p) as im:
                    im.verify()
                with Image.open(p) as im:
                    w, h, mode = im.width, im.height, im.mode
                hashes[digest].append(rel)
                image_rows.append(dict(split=split, path=rel, filename=p.name,
                    class_folder=p.parent.name, width=w, height=h, mode=mode,
                    size_bytes=p.stat().st_size, sha256=digest, readable=True, error=""))
            except Exception as e:
                image_rows.append(dict(split=split, path=rel, filename=p.name,
                    class_folder=p.parent.name, width="", height="", mode="",
                    size_bytes=p.stat().st_size, sha256="", readable=False, error=str(e)))
    duplicate_rows = []
    for i, paths in enumerate((v for v in hashes.values() if len(v) > 1), 1):
        duplicate_rows.append(dict(group=i, paths=" | ".join(paths), count=len(paths)))

    matching_rows, objects, bbox_issues, xml_errors = [], [], [], []
    for split in ("train", "validation", "test"):
        sd = dataset / split
        ims = {p.stem: p for p in images_in(sd)}
        xms = {p.stem: p for p in xmls_in(sd)}
        for stem in sorted(set(ims) | set(xms)):
            matching_rows.append(dict(split=split, stem=stem, image_exists=stem in ims,
                xml_exists=stem in xms,
                status="matched" if stem in ims and stem in xms else
                ("image_without_xml" if stem in ims else "xml_without_image")))
        for xp in xmls_in(sd):
            try:
                root = ET.parse(xp).getroot()
                size = root.find("size")
                iw = int(size.findtext("width")) if size is not None and size.findtext("width") else None
                ih = int(size.findtext("height")) if size is not None and size.findtext("height") else None
                for obj in root.findall("object"):
                    name = (obj.findtext("name") or "").strip()
                    box = obj.find("bndbox")
                    row = dict(split=split, xml=str(xp.relative_to(dataset)), object_name=name,
                               xmin="", ymin="", xmax="", ymax="", image_width_xml=iw or "",
                               image_height_xml=ih or "")
                    if box is None:
                        bbox_issues.append(dict(xml=row["xml"], object_name=name, issue="missing bndbox"))
                    else:
                        try:
                            vals = {k: float(box.findtext(k)) for k in ("xmin","ymin","xmax","ymax")}
                            row.update(vals)
                            if vals["xmin"] >= vals["xmax"] or vals["ymin"] >= vals["ymax"]:
                                bbox_issues.append(dict(xml=row["xml"], object_name=name, issue=f"invalid coordinates: {vals}"))
                            if iw and ih and (vals["xmin"] < 0 or vals["ymin"] < 0 or vals["xmax"] > iw or vals["ymax"] > ih):
                                bbox_issues.append(dict(xml=row["xml"], object_name=name, issue=f"coordinates outside image: {vals}"))
                        except Exception as e:
                            bbox_issues.append(dict(xml=row["xml"], object_name=name, issue=f"unreadable coordinates: {e}"))
                    objects.append(row)
            except Exception as e:
                xml_errors.append(dict(xml=str(xp.relative_to(dataset)), error=str(e)))

    class_counts = defaultdict(int)
    for row in image_rows:
        class_counts[(row["split"], row["class_folder"])] += 1
    class_rows = [dict(split=k[0], class_folder=k[1], image_count=v) for k,v in sorted(class_counts.items())]

    write_csv(out/"audit_images.csv", image_rows)
    write_csv(out/"duplicate_groups.csv", duplicate_rows)
    write_csv(out/"image_xml_matching.csv", matching_rows)
    write_csv(out/"annotation_objects.csv", objects)
    write_csv(out/"bbox_issues.csv", bbox_issues)
    write_csv(out/"xml_errors.csv", xml_errors)
    write_csv(out/"class_distribution.csv", class_rows)
    summary = dict(dataset_dir=str(dataset), total_images=len(image_rows),
        readable_images=sum(bool(r["readable"]) for r in image_rows),
        unreadable_images=sum(not bool(r["readable"]) for r in image_rows),
        duplicate_hash_groups=len(duplicate_rows),
        xml_parse_errors=len(xml_errors), bbox_issues=len(bbox_issues),
        image_xml_mismatch_rows=sum(r["status"] != "matched" for r in matching_rows))
    (out/"audit_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    print(f"CSV/JSON hasil tersimpan di: {out}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", required=True, help="Folder yang berisi train/ dan validation/")
    parser.add_argument("--output", default="audit_results", help="Folder output hasil audit")
    args = parser.parse_args()
    main(args.dataset, args.output)

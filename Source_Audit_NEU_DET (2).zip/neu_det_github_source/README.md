# Audit Dataset NEU Surface Defect

Paket source untuk audit dasar dataset NEU Surface Defect Database.

**Nama laporan:** Aditya Setyo Nugroho  
**NIM:** 2395114025

## Ringkasan hasil audit
- 1.800 citra JPG dan 1.800 XML.
- 6 kelas, 300 citra per kelas.
- Train 1.440; validation 360.
- Ukuran citra 200×200; mode RGB saat dibaca dari arsip yang diperiksa.
- 1 grup duplikat SHA-256: `patches_101.jpg` dan `patches_105.jpg`.
- 0 error parsing XML; 0 bounding box invalid pada pemeriksaan dasar.
- 4.189 objek anotasi.
- 1 mismatch split: `crazing_240.jpg` berada di train, sedangkan XML pasangannya berada di validation.

Lihat `docs/Laporan_Audit_Dataset.md` untuk uraian, interpretasi, rekomendasi, dan keterbatasan.

## Sumber
https://www.kaggle.com/datasets/kaustubhdikshit/neu-surface-defect-database/code

## Catatan lisensi
Status lisensi pada halaman Kaggle tercatat sebagai `Unknown`. Jangan sertakan atau unggah dataset mentah ke repositori publik sebelum izin redistribusi diperiksa.

## Menjalankan source
Jika menggunakan skrip audit/notebook yang tersedia, pasang dependensi yang tercantum pada `requirements.txt`, lalu ikuti instruksi pada notebook. Hasil laporan ini merekam hasil audit arsip yang diperiksa; angka di atas bukan angka simulasi.

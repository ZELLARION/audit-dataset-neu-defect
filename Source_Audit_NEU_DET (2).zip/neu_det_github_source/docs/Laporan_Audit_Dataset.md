# Laporan Audit Dataset NEU Surface Defect

**Nama:** Aditya Setyo Nugroho  
**NIM:** 2395114025

## 1. Deskripsi domain
Dataset NEU Surface Defect Database memuat enam kelas cacat permukaan baja: `crazing`, `inclusion`, `patches`, `pitted_surface`, `rolled-in_scale`, dan `scratches`.

## 2. Struktur dataset
Audit terhadap arsip yang diberikan menemukan 1.800 citra JPG dan 1.800 XML, citra berukuran 200×200 piksel, dan mode RGB saat dibaca. Halaman Kaggle mendeskripsikan dataset sebagai 1.800 citra grayscale; perbedaan deskripsi sumber dan mode file hasil pemeriksaan dicatat tanpa diasumsikan sebagai kesalahan.

| Aspek | Hasil |
|---|---|
| Citra | 1.800 JPG |
| XML | 1.800 |
| Kelas | 6 |
| Dimensi | 200×200 |
| Mode file saat dibaca | RGB |
| Train / validation | 1.440 / 360 |

Tabel ini merangkum struktur arsip yang diaudit. Jumlah file total yang sama tidak menjamin pasangan citra-XML berada pada split yang sama.

## 3. Distribusi per kelas

| Kelas | Train | Validation | Total |
|---|---:|---:|---:|
| crazing | 240 | 60 | 300 |
| inclusion | 240 | 60 | 300 |
| patches | 240 | 60 | 300 |
| pitted_surface | 240 | 60 | 300 |
| rolled-in_scale | 240 | 60 | 300 |
| scratches | 240 | 60 | 300 |
| **Total** | **1.440** | **360** | **1.800** |

Tabel menunjukkan distribusi seimbang dengan rasio train-validation 80:20.

## 4. Hasil audit integritas
- Semua 1.800 citra berhasil dibaca.
- Semua 1.800 XML berhasil diurai; 0 error parsing.
- 0 bounding box invalid/di luar batas pada pemeriksaan dasar.
- Total 4.189 objek anotasi.
- 1 grup file identik SHA-256: `patches_101.jpg` dan `patches_105.jpg`.
- 1 mismatch split: `crazing_240.jpg` ada di train, sedangkan `crazing_240.xml` ada di validation.

Temuan duplikasi dan mismatch perlu ditinjau sebelum eksperimen. Hash SHA-256 hanya menemukan identitas byte, bukan semua duplikasi visual.

## 5. Rekomendasi
1. Verifikasi `patches_101.jpg` dan `patches_105.jpg`, lalu catat keputusan.
2. Cocokkan kembali pasangan `crazing_240.jpg` dan `crazing_240.xml` berdasarkan struktur sumber.
3. Jalankan ulang audit setelah koreksi.
4. Hindari duplikasi lintas split untuk mencegah data leakage.
5. Lakukan pemeriksaan visual sampel anotasi dan label.
6. Terapkan augmentasi hanya pada data train setelah split.
7. Simpan manifest dan log agar proses dapat direproduksi.

## 6. Keterbatasan
Audit ini tidak membuktikan semua label benar secara semantik, tidak mendeteksi semua duplikasi visual non-identik, dan tidak mengukur performa model. Bounding box yang lolos pemeriksaan koordinat tetap perlu ditinjau secara visual.

## 7. Kesimpulan
Arsip berisi 1.800 citra dan 1.800 XML pada enam kelas. Seluruh citra terbaca dan XML dapat diurai. Ditemukan satu grup duplikat identik dan satu mismatch pasangan pada split yang perlu ditindaklanjuti.

## Sumber
Kaggle. (n.d.). *NEU Surface Defect Database*. https://www.kaggle.com/datasets/kaustubhdikshit/neu-surface-defect-database/code

**Lisensi:** halaman Kaggle menunjukkan status lisensi `Unknown`. Jangan mengunggah dataset mentah ke repositori publik sebelum izin redistribusi dipastikan.
